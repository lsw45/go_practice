// db.card_pay_activity.dropIndex("merchantCode_1")
// db.card_pay_activity.createIndex({"merchantCode":1},{"unique":true,"sparse":true})
db.card_pay_activity.getIndexes()