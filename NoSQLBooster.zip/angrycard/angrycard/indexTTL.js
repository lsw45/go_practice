function getCollectionIndexInfo(collection, indexName) {
    const dbVersion = parseFloat(db.version());
    const indexInfo = db.getCollection(collection).getIndexes().find(it => it.name === indexName);


    const stats = (() => {
        if (dbVersion >= 3.0) {
            try{
                return db.getCollection(collection).stats({ indexDetails: true, indexDetailsName: indexName });
            } catch (error){
                console.error(error);
            }
        }
    })();
    
    const indexDetails=(()=>{
        if (_.isEmpty((stats))) return;
        
        if (stats.indexDetails) {
            return stats.indexDetails[indexName];
        }
    
        if (stats.shards) {
            return _.transform(stats.shards, function(result, value, key) {
                result[key] = {
                    name: indexName,
                    indexSize: _.get(value, "indexSizes." + indexName),
                    ..._.get(value, "indexDetails." + indexName)
                }
            }, {});
        }
    })();
    

    const indexStats = (() => {
        if (dbVersion >= 3.2) {
            try{
                return db.getCollection(collection).aggregate([{ $indexStats: {} }]).toArray().filter(it => it.name === indexName)
            } catch (error){
                console.error(error)            
            }
        }
    })();

    return ({ ...indexInfo, indexSize: stats && stats.indexSizes[indexName],  "usage stats": indexStats, "index details": indexDetails })
}

getCollectionIndexInfo("card_pay_activity","cache_created_at_1");

// db.card_pay_activity.dropIndex("cache_created_at_1")

// db.card_pay_activity.createIndex({"cache_created_at":1},{expireAfterSeconds:600})

// db.card_pay_activity.dropIndex("merchantCode_1")
// db.card_pay_activity.createIndex({"merchantCode":1},{"unique":true,"sparse":true})
db.card_pay_activity.getIndexes()