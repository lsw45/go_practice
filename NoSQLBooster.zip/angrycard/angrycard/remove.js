// db.card_pay_activity.remove({"updated_at": {$lt:ISODate("2019-10-19T16:45:52.989+08:00")}},{justOne:false})

// db.card_pay_activity.remove({ 
//     "_id": { 
//         $in: [ObjectId("5daac5c3129dfb3713604e04"), ObjectId("5daac527129dfb3713604e03"), ObjectId("5daac5c3129dfb3713604e04"), ObjectId("5daac4d9129dfb3713604e02")]
//     } 
// })

db.card_pay_activity.update({"_id":ObjectId("5daacd40e7e1063ef07e44b9")},{$set:{"merchantCode":"jt20191017170245924449"}})