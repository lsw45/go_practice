db.cardCommon.find({"mobileNo":"16621350306"})
// db.cardCommon.remove({"_id":ObjectId("5db7fbb4129dfb3713608e76")})
// db.cardCommon.update({"mobileNo":"17717286451","merchantCode":"jt20180528102410333649"},{$set:{memCardPayEffectDate:new Date()}})

var mongoCollection = db.getCollection('startup_log');
for (var i = 0; i < 1; i++)
{
    var doc = {};
    doc["ID"] = i;
    doc["Msg"] = "value is "+ i;
    mongoCollection.insert(doc);
}