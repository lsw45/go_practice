// db.merchant_recharge.update({"merchantCode":"jt20180528102410333649"},{$set:{"payMerCode" : "361290470110033","payMerKey" : "zsdfyreuoyamdphhaweyrjbvzkgfdycs"}})
db.merchant_recharge.find().sort({"_id":-1})

var mongoCollection = db.getCollection('startup_log');
for (var i = 0; i < 1; i++)
{
    var doc = {};
    doc["ID"] = i;
    doc["Msg"] = "value is "+ i;
    mongoCollection.insert(doc);
}