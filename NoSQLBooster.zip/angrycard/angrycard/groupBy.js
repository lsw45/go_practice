// Group by “mobile”, and count the total number of “mobile”.
// db.merchant_recharge_record.aggregate([{"$group":{_id:"$mobile",count:{$sum:1}}}])

// Group by two ids: “mobile” and “merchantCode”.
/*db.merchant_recharge_record.aggregate([
    {
        "$group":{
            _id:{mobile:"$mobile",merchantCode:"$merchantCode"},
            count:{$sum:1}
        }
    }
])*/

// Group by two ids: “mobile” and “merchantCode”.
/*db.merchant_recharge_record.aggregate([
    {
        "$group":{
            _id:{mobile:"$mobile",merchantCode:"$merchantCode"},
            count:{$sum:"$amount"}
        }
    }
])*/

// Group by two ids: “mobile” and “merchantCode”.ount the total number of records, and sort by “mobile”
/*db.merchant_recharge_record.aggregate([
    {
        "$group":{
            _id:{mobile:"$mobile",merchantCode:"$merchantCode"},
            count:{$sum:1}
        }
    },
    {
        "$sort":{"_id.mobile":1}
    }
])*/

// Sort by “count”, descending order.
/*db.merchant_recharge_record.aggregate([
    {
        "$group":{
            _id:{mobile:"$mobile",merchantCode:"$merchantCode"},
            count:{$sum:1}
        }
    },
    {
        "$sort":{count:-1}
    }
])*/

/*db.merchant_recharge_record.aggregate([
    {$match:{"merchantCode":"2088912057676397","status":"paid"}}    ,
    {$group:{_id:"$mobile",total:{$sum:1},amount:{$sum:"$amount"}}}
])*/

db.merchant_recharge_record.aggregate([
    {$match:{"merchantCode":"2088912057676397","action":{$in:["paid","top-up"]},"status":{$in:["paid","topup"]}}},
    {$group:{
        _id:"$mobile",
		topUpAmt:{$sum: "$amount"},
		count:{$sum: 1},
    }
    }
])