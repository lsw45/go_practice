// db.createCollection("cardInfo", { capped : true, size : 50 * 1024 * 1024, max : 100 * 100 } )  
// db.createCollection("log", { capped : true, size : 524288, max : 5000 } )
// db.createCollection("person",{capped:true,size:1024,max:1000})
// db.person.insert({"name":"ccc","sex":1})
// db.person.find({"name":"carey"}).explain("executionStats")
// db.person.find({"name":"carey"}).pretty()
// db.person.find({"name":"carey"}).explain()
// db.person.find({"$or":[{"name":"carey","age":24},{"age":27})

// 'where likes>50 AND (by = '菜鸟教程' OR title = 'MongoDB 教程')'
// db.runCommand({"convertToCapped": "person", size: 100 * 1024 * 10240});
db.serverStatus().connections
db.person.update({"name":"carey"}, 
    {$set:{"name":"ca001"}}
)
db.person.find({"likes":"50"})

db.log.stats()