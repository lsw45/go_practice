// db.createCollection("cardInfo")
// db.cardInfo.createIndex({"createdAt":1},{expireAfterSeconds:180})
// db.cardInfo.createIndex({"createdAt":1},{expireAfterSeconds:180},{background:true})//后台创建索引
// db.cardInfo.insert({
//     "createdAt": new Date(),
//     "logEvent": 2,
//     "logMessage": "Success!"
// })
// db.cardInfo.find().pretty()
// db.cardInfo.insert({
//     "expire": new Date('Mar 11, 2016 09:30:00'),
//     "logEvent": 3,
//     "logMessage": "Success!"
// })
db.cardInfo.stats()
db.cardInfo.getIndexes()
db.cardInfo.totalIndexSize()
