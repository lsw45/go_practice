// db.createCollection("log")
// db.log.drop()
// db.log.insert({"time":new Date("2012-7-9"),"trace":"001"})

// db.log.find().pretty()

// db.log.update({"_id":1},{"total":20},{upsert:true})

// 更新：
db.log.update({'title':'MongoDB 教程'}, {$set: {'title':'MongoDB'}})

// 如果数据不存在需要插入，设置 upsert:true 即可：
db.log.update({'title':'MongoDB 教程'}, {$set: {'title':'MongoDB'}},{upsert:true})

// 数据存在时不进行操作：
db.log.update({'title':'MongoDB 教程'}, {$setOnInsert: {'title':'MongoDB'}})

// 返回指定字段,只能同时为1或者0，否则报错：Projection cannot have a mix of inclusion and exclusion.
db.log.find({trace:"001"},{time:1,trace:1})