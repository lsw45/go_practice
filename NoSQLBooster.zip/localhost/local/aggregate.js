db.log.aggregate([{
    $lookup:{
        from:"person",
        localField:"name",
        foreignField:"sku",
        as:"person_log"
    }
}]).sort("_id")